// const { assert } = require("chai")
// const { loadFixture } = require("@nomicfoundation/hardhat-network-helpers")
// const { network } = require("hardhat")

describe("Functions Consumer Unit Tests", async function () {
  // We define a fixture to reuse the same setup in every test.
  // We use loadFixture to run this setup once, snapshot that state,
  // and reset Hardhat Network to that snapshot in every test.

  it("empty test", async () => {
    // TODO
  })
})
